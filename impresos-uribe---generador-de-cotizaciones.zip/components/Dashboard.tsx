import React from 'react';
import { Quote } from '../types';
import { Plus, Edit2, Trash2, FileText, Search } from 'lucide-react';

interface DashboardProps {
  quotes: Quote[];
  onCreate: () => void;
  onEdit: (quote: Quote) => void;
  onDelete: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ quotes, onCreate, onEdit, onDelete }) => {
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredQuotes = quotes.filter(
    (q) => q.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => b.updatedAt - a.updatedAt); // Sort by newest

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
            <div className="flex items-center gap-2">
                <div className="bg-blue-600 p-2 rounded-lg -rotate-3 shadow-md">
                     <FileText className="text-white w-6 h-6" />
                </div>
                <div>
                    <h1 className="text-xl font-bold text-gray-900 tracking-tight">IMPRESOS URIBE</h1>
                    <p className="text-xs text-gray-500 font-medium">Sistema de Cotizaciones</p>
                </div>
            </div>
            <button
                onClick={onCreate}
                className="flex items-center bg-blue-600 text-white px-5 py-2.5 rounded-full hover:bg-blue-700 transition-all shadow-lg hover:shadow-blue-500/30 font-medium text-sm"
            >
                <Plus size={18} className="mr-2" />
                Nueva Cotización
            </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats / Header */}
        <div className="mb-8 flex flex-col sm:flex-row justify-between items-end gap-4">
            <div>
                 <h2 className="text-2xl font-bold text-gray-800">Historial</h2>
                 <p className="text-gray-500 mt-1">Gestiona tus cotizaciones generadas</p>
            </div>
            
            <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                <input 
                    type="text" 
                    placeholder="Buscar por cliente..." 
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-shadow"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>

        {/* Grid */}
        {filteredQuotes.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-300">
                <div className="bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <FileText className="text-gray-400 w-8 h-8" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">No hay cotizaciones aún</h3>
                <p className="text-gray-500 mb-6">Crea la primera cotización para empezar.</p>
                <button onClick={onCreate} className="text-blue-600 font-medium hover:underline">Crear ahora</button>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredQuotes.map((quote) => (
                    <div key={quote.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow group">
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="font-bold text-lg text-gray-800 truncate pr-2">{quote.clientName}</h3>
                                <span className="text-xs font-medium text-gray-400 bg-gray-100 px-2 py-1 rounded-md">
                                    {new Date(quote.date).toLocaleDateString()}
                                </span>
                            </div>
                            <div className="bg-blue-50 text-blue-600 text-xs font-bold px-3 py-1 rounded-full">
                                {quote.items.length} Items
                            </div>
                        </div>
                        
                        <div className="h-px bg-gray-100 my-4"></div>

                        <div className="flex items-center justify-between text-sm">
                             <span className="text-gray-500">Total aprox.</span>
                             <span className="font-bold text-gray-800 text-lg">
                                ${quote.items.reduce((sum, item) => sum + item.price, 0).toLocaleString()}
                             </span>
                        </div>

                        <div className="mt-6 flex gap-2">
                            <button 
                                onClick={() => onEdit(quote)}
                                className="flex-1 flex justify-center items-center py-2 px-4 rounded-lg bg-gray-50 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors font-medium text-sm border border-gray-200 hover:border-blue-200"
                            >
                                <Edit2 size={16} className="mr-2" /> Abrir / Editar
                            </button>
                             <button 
                                onClick={() => {
                                    if(confirm('¿Estás seguro de eliminar esta cotización?')) {
                                        onDelete(quote.id);
                                    }
                                }}
                                className="p-2 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500 transition-colors"
                                title="Eliminar"
                            >
                                <Trash2 size={18} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        )}
      </main>
    </div>
  );
};
