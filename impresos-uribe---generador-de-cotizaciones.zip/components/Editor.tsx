import React, { useState, useEffect } from 'react';
import { Quote, LineItem } from '../types';
import { Plus, Trash2, Save, ArrowLeft, Download } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { QuotePreview } from './QuotePreview';

interface EditorProps {
  initialQuote?: Quote | null;
  onSave: (quote: Quote) => void;
  onCancel: () => void;
}

export const Editor: React.FC<EditorProps> = ({ initialQuote, onSave, onCancel }) => {
  const [clientName, setClientName] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [items, setItems] = useState<LineItem[]>([]);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Ref for the hidden preview used for PDF generation
  const printRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialQuote) {
      setClientName(initialQuote.clientName);
      setDate(initialQuote.date);
      setItems(initialQuote.items);
    } else {
      // Default initial item
      setItems([{ id: uuidv4(), description: '', price: 0 }]);
    }
  }, [initialQuote]);

  const handleAddItem = () => {
    setItems([...items, { id: uuidv4(), description: '', price: 0 }]);
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const handleItemChange = (id: string, field: keyof LineItem, value: string | number) => {
    setItems(items.map((item) => (item.id === id ? { ...item, [field]: value } : item)));
  };

  const handleSave = () => {
    if (!clientName) {
        alert("Por favor ingresa el nombre del cliente.");
        return;
    }
    const quoteToSave: Quote = {
      id: initialQuote ? initialQuote.id : uuidv4(),
      clientName,
      date,
      items,
      createdAt: initialQuote ? initialQuote.createdAt : Date.now(),
      updatedAt: Date.now(),
    };
    onSave(quoteToSave);
  };

  const generatePDF = async () => {
    if (!printRef.current) return;
    setIsGeneratingPdf(true);

    try {
        // Wait for fonts to load for better rendering
        await document.fonts.ready;

        const canvas = await html2canvas(printRef.current, {
            scale: 2, // Higher scale for better quality
            useCORS: true,
            logging: false,
            backgroundColor: '#ffffff'
        });

        const imgData = canvas.toDataURL('image/png');
        
        // A4 size in mm
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'mm',
            format: 'a4'
        });

        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`Cotizacion-${clientName.replace(/\s+/g, '-')}-${date}.pdf`);
    } catch (error) {
        console.error("Error generating PDF", error);
        alert("Hubo un error generando el PDF.");
    } finally {
        setIsGeneratingPdf(false);
    }
  };

  const currentQuoteData: Quote = {
    id: initialQuote?.id || 'temp',
    clientName: clientName || 'Nombre del Cliente',
    date,
    items,
    createdAt: 0,
    updatedAt: 0,
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen overflow-hidden bg-gray-100">
      {/* Left Side: Form Controls */}
      <div className="w-full lg:w-1/3 bg-white border-r border-gray-200 flex flex-col h-full shadow-lg z-10">
        <div className="p-6 border-b border-gray-100 bg-white">
            <button onClick={onCancel} className="flex items-center text-gray-500 hover:text-gray-800 mb-4 transition-colors">
                <ArrowLeft size={16} className="mr-1" /> Volver al Tablero
            </button>
            <h2 className="text-2xl font-bold text-gray-800 mb-1">
                {initialQuote ? 'Editar Cotización' : 'Nueva Cotización'}
            </h2>
            <p className="text-sm text-gray-500">Ingresa los datos para generar el documento.</p>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* General Info */}
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
                    <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Dirigido a (Cliente)</label>
                    <input
                        type="text"
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                        placeholder="Ej. Srta. Dulce Luna"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>
            </div>

            <hr className="border-gray-100" />

            {/* Line Items */}
            <div>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium text-gray-800">Conceptos</h3>
                    <button
                        onClick={handleAddItem}
                        className="flex items-center text-sm text-blue-600 hover:text-blue-800 font-medium"
                    >
                        <Plus size={16} className="mr-1" /> Agregar Fila
                    </button>
                </div>
                
                <div className="space-y-4">
                    {items.map((item, index) => (
                        <div key={item.id} className="bg-gray-50 p-4 rounded-lg border border-gray-100 relative group">
                            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                    onClick={() => handleRemoveItem(item.id)}
                                    className="text-red-400 hover:text-red-600 p-1"
                                    title="Eliminar fila"
                                >
                                    <Trash2 size={16} />
                                </button>
                            </div>
                            <div className="mb-2">
                                <label className="text-xs font-semibold text-gray-500 uppercase">Descripción</label>
                                <textarea
                                    value={item.description}
                                    onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                                    placeholder="Descripción del producto o servicio..."
                                    className="w-full mt-1 px-3 py-2 bg-white border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    rows={3}
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase">Precio Unitario</label>
                                <div className="relative mt-1">
                                    <span className="absolute left-3 top-2 text-gray-500">$</span>
                                    <input
                                        type="number"
                                        value={item.price}
                                        onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value) || 0)}
                                        className="w-full pl-7 pr-3 py-2 bg-white border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>

        {/* Action Buttons */}
        <div className="p-6 border-t border-gray-200 bg-gray-50 flex gap-3">
             <button
                onClick={handleSave}
                className="flex-1 flex justify-center items-center bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium"
            >
                <Save size={18} className="mr-2" />
                Guardar
            </button>
            <button
                onClick={generatePDF}
                disabled={isGeneratingPdf}
                className="flex-1 flex justify-center items-center bg-gray-800 text-white px-4 py-3 rounded-lg hover:bg-gray-900 transition-colors shadow-sm font-medium disabled:opacity-50"
            >
                {isGeneratingPdf ? 'Generando...' : (
                    <>
                        <Download size={18} className="mr-2" />
                        PDF
                    </>
                )}
            </button>
        </div>
      </div>

      {/* Right Side: Live Preview */}
      <div className="hidden lg:flex flex-1 bg-gray-200 justify-center items-start overflow-y-auto p-8">
        <div className="transform scale-[0.6] origin-top shadow-2xl">
            <QuotePreview quote={currentQuoteData} />
        </div>
      </div>

      {/* Hidden container for PDF generation (Rendered at actual size/scale) */}
      <div className="fixed top-0 left-0 -z-50 opacity-0 pointer-events-none">
         <div className="w-[800px]">
             <QuotePreview ref={printRef} quote={currentQuoteData} />
         </div>
      </div>
    </div>
  );
};
