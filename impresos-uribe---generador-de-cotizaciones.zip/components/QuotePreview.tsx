import React, { forwardRef } from 'react';
import { Quote, COMPANY_INFO } from '../types';

interface QuotePreviewProps {
  quote: Quote;
}

// Using forwardRef to allow the parent to capture this DOM element for PDF generation
export const QuotePreview = forwardRef<HTMLDivElement, QuotePreviewProps>(({ quote }, ref) => {
  
  // Format date to "29 DE SEPTIEMBRE DEL 2025"
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString + 'T00:00:00'); // Fix timezone issues by treating as local
    return new Intl.DateTimeFormat('es-MX', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date).toUpperCase().replace(' DE ', ' DE ').replace(' 20', ' DEL 20');
  };

  const formattedDate = formatDate(quote.date);

  return (
    <div ref={ref} className="w-[800px] min-h-[1131px] bg-white relative overflow-hidden text-gray-800 shadow-2xl mx-auto dot-pattern">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-50 rounded-full blur-3xl opacity-50 translate-x-1/3 -translate-y-1/3 pointer-events-none"></div>
      
      {/* Header Bar */}
      <div className="absolute top-28 right-0 w-[50%] h-12 bg-[#5faad9] z-10 rounded-l-full flex items-center justify-center pr-8 shadow-sm">
      </div>
      <div className="absolute top-28 right-0 w-[50%] h-12 z-20 flex items-center justify-end pr-16">
         <h1 className="text-3xl font-bold text-white italic tracking-wide">COTIZACIÓN</h1>
      </div>

       {/* Date Sub-header */}
       <div className="absolute top-40 right-16 text-right">
        <p className="text-sm font-bold text-gray-600 uppercase tracking-widest">{formattedDate}</p>
      </div>


      <div className="p-12 pt-32 relative z-10 h-full flex flex-col">
        {/* Company Header */}
        <div className="mb-20">
            {/* Logo Placeholder - in a real app this would be an <img> */}
            <div className="w-48 h-16 bg-blue-600 rounded-lg -rotate-2 flex items-center justify-center mb-8 shadow-lg">
                <span className="text-white font-bold text-lg italic">PROCESSIONALES</span>
            </div>

            <h2 className="text-4xl font-extrabold text-gray-800 italic mb-2 tracking-wide uppercase">{COMPANY_INFO.name}</h2>
            <div className="text-gray-600 space-y-1 text-sm font-medium">
                <p>MÓVIL - {COMPANY_INFO.phone}</p>
                <p>EMAIL - {COMPANY_INFO.email}</p>
            </div>
        </div>

        {/* Client Info */}
        <div className="mb-8 pl-2">
            <p className="font-bold text-lg text-gray-800">{quote.clientName}</p>
            <p className="text-gray-500 text-sm uppercase">ENVÍO PRESUPUESTO DE MATERIAL SOLICITADO.</p>
        </div>

        {/* Table */}
        <div className="flex-grow">
            <div className="w-full border-2 border-[#5faad9] rounded-2xl overflow-hidden bg-white">
                <div className="flex bg-[#5faad9] text-white font-bold py-2 px-4">
                    <div className="w-16 text-center">LISTA</div>
                    <div className="flex-1 text-center">DESCRIPCIÓN</div>
                    <div className="w-32 text-center">PRECIO</div>
                </div>
                
                <div className="divide-y divide-gray-100">
                    {quote.items.map((item, index) => (
                        <div key={item.id} className="flex py-6 px-4 items-center">
                            <div className="w-16 text-center font-bold text-gray-700 text-xl">{index + 1}</div>
                            <div className="flex-1 px-4 text-gray-700 text-sm leading-relaxed">
                                {item.description}
                            </div>
                            <div className="w-32 text-center font-bold text-gray-500 text-lg">
                                ${item.price} <span className="text-xs text-gray-400 font-normal">C/uno</span>
                            </div>
                        </div>
                    ))}
                    
                    {quote.items.length === 0 && (
                        <div className="p-8 text-center text-gray-400 italic">
                            No hay artículos en esta cotización.
                        </div>
                    )}
                </div>
            </div>
            
            <div className="mt-4 flex justify-between items-start px-2">
                <p className="text-xs text-gray-500 w-1/2 uppercase">
                    Quedo a sus órdenes para cualquier duda o comentario, gracias.
                </p>
                <p className="text-lg font-medium text-gray-800">
                    Todos estos precios son más IVA
                </p>
            </div>
        </div>

        {/* Footer */}
        <div className="mt-20 border-l-4 border-blue-500 pl-4 mb-10">
            <p className="text-xs font-bold text-gray-500 mb-1">SALUDOS</p>
            <p className="font-bold text-gray-800 text-lg uppercase">{COMPANY_INFO.contactName}</p>
        </div>
        
        {/* Bottom Decorative Bar */}
        <div className="absolute bottom-10 right-0 w-[50%] h-12 bg-[#5faad9] rounded-l-full flex items-center justify-end pr-10">
             <h2 className="text-3xl font-bold text-white/90 italic tracking-wide">COTIZACIÓN</h2>
        </div>
        <div className="absolute bottom-10 left-0 w-[40%] h-8 bg-[#3b82f6]"></div>

      </div>
    </div>
  );
});

QuotePreview.displayName = 'QuotePreview';
